from django.db import models

from products.models import AbstractCar




class Car(AbstractCar):
    pass
