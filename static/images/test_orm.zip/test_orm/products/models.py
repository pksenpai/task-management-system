from django.db import models




class AbstractCar(models.Model):
    manufacturer = models.ForeignKey("Manufacturer", on_delete=models.CASCADE)

    class Meta:
        abstract = True

class Manufacturer(models.Model):
    title = models.CharField(max_length=200)

