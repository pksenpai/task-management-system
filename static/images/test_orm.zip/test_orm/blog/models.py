from django.db import models
from django.template.defaultfilters import slugify





class Personi(models.Model):

    title = models.CharField(max_length=200)

    slug  = models.SlugField()


    # def save(self, *args, **kwargs):
        
    #     if self.slug:
    #         self.slug = slugify(self.title)
    #         return super().save(*args, **kwargs)




